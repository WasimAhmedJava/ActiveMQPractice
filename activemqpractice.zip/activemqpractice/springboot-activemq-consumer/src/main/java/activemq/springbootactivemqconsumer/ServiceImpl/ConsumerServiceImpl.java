package activemq.springbootactivemqconsumer.ServiceImpl;

import org.springframework.stereotype.Service;

import activemq.springbootactivemqconsumer.Service.ConsumerService;

@Service
public class ConsumerServiceImpl implements ConsumerService {

}
