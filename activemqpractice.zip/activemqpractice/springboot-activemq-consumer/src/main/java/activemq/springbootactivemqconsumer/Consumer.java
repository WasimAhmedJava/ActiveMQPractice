package activemq.springbootactivemqconsumer;

import java.util.List;

import javax.jms.JMSException;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer {
	
	@JmsListener(destination="simplequeue")
	public void receiveFruit(String message) throws JMSException{
		System.out.println("Message Received is :" + message);
	}

	@JmsListener(destination="myqueue")
	public void receiveFruitDetails(final List<String> fruitList) throws JMSException{
		System.out.println("Fruit Details is :" + fruitList);
	}

}
