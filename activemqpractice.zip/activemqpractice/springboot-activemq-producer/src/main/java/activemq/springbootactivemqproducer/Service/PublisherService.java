package activemq.springbootactivemqproducer.Service;

import org.springframework.stereotype.Service;

@Service
public interface PublisherService {
	
	public void publishMessage();
	
	public void publishSimpleMessage(String message);
}
