package activemq.springbootactivemqproducer.ServiceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Service;

import activemq.springbootactivemqproducer.Service.PublisherService;

@Service
public class PublisherServiceImpl implements PublisherService {
	
	@Autowired
    JmsMessagingTemplate jmsMessagingTemplate;

	@Override
	public void publishMessage() {
		// TODO Auto-generated method stub
		List<String> queueList = new ArrayList<String>();
		queueList.add("Apple");
		queueList.add("Bannana");
		queueList.add("Mango");
		queueList.add("Kiwi");
		queueList.add("PineApple");
        this.jmsMessagingTemplate.convertAndSend("myqueue", queueList);
	}

	

	@Override
	public void publishSimpleMessage(String message) {
		// TODO Auto-generated method stub
		this.jmsMessagingTemplate.convertAndSend("simplequeue", message);
	}

}
