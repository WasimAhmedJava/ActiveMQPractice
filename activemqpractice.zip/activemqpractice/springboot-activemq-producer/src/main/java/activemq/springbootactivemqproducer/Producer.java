package activemq.springbootactivemqproducer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import activemq.springbootactivemqproducer.Service.PublisherService;

@RestController
@RequestMapping("/rest")
public class Producer {
	
	@Autowired
	PublisherService publisherService;
	
	@GetMapping("/getMessage/{message}")
	public String publishMesage(@PathVariable("message") String message) {
		publisherService.publishSimpleMessage(message);
		return "Published Successfully";
		
	}
	
	@GetMapping("/sendFruitDetails")
	public String sendFruitDetails() {
		publisherService.publishMessage();
		return "Sent Successfully";
	}
	
	
}
